package com.illumina.illumina_onlinebookmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class})
public class IlluminaOnlinebookmanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(IlluminaOnlinebookmanagementApplication.class, args);
	}

}
