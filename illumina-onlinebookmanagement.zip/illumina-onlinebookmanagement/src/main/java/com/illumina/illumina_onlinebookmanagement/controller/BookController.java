package com.illumina.illumina_onlinebookmanagement.controller;

import com.illumina.illumina_onlinebookmanagement.model.Book;
import com.illumina.illumina_onlinebookmanagement.service.BookService;
import jakarta.websocket.server.PathParam;
import lombok.extern.slf4j.XSlf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/illumina")
@XSlf4j
public class BookController {

    private static final Logger log = LoggerFactory.getLogger(BookController.class);
    @Autowired
    private BookService bookService;

    @GetMapping("/allBook")
    public List<Book> getAllBookIsAvailable(){
        return bookService.getAllBook();
    }

    @GetMapping("/book/id")
    public List<Book> getBookById(@PathParam("id") String id){
        return bookService.getBookIdValue(id);
    }

    @PutMapping("/book/{id}")
    public Book updateBook(@PathVariable(value = "id") String bookId,
                           @Validated @RequestBody Book bookDetails) {

        return bookService.updateBook(bookId,bookDetails);
    }

    @PostMapping("/book")
    public Book createBook(@RequestBody Book book){
        return bookService.createBook(book);
    }

    @DeleteMapping("deleteById")
    public void deleteBookById(@PathParam("id") String id){
        log.info("Delete By ID",id);
        bookService.deleteBookById(id);
    }
}
