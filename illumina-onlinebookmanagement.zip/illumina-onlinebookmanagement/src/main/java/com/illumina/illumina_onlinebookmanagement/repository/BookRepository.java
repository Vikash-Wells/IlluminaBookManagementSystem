package com.illumina.illumina_onlinebookmanagement.repository;

import com.illumina.illumina_onlinebookmanagement.model.Book;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface BookRepository extends MongoRepository<Book, String> {
    @Override
    List<Book> findAll();

    List<Book> findByBookId(String s);

    @Override
    List<Book> findAllById(Iterable<String> strings);

    @Override
    <S extends Book> S save(S entity);

    @Override
    void deleteById(String s);

    void deleteByBookId(String s);
}

