package com.illumina.illumina_onlinebookmanagement.service;

import com.illumina.illumina_onlinebookmanagement.exception.BookExceptionHandler;
import com.illumina.illumina_onlinebookmanagement.model.Book;
import com.illumina.illumina_onlinebookmanagement.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

@Service
public class BookService {
    @Autowired
    private BookRepository bookRepository;

    public List<Book> getAllBook(){
        return bookRepository.findAll();
    }

    public List<Book> getBookIdValue(String bookId){
        return bookRepository.findByBookId(bookId);
    }

    public Book createBook(Book book){
        return bookRepository.save(book);
    }

    public Book updateBook(String id,Book book){
        bookRepository.findByBookId(id);
        book.setBookId(id);
        Book updateBook = bookRepository.save(book);
        return updateBook;
    }
    public void deleteBookById(String id){
        bookRepository.deleteByBookId(id);
    }
}
